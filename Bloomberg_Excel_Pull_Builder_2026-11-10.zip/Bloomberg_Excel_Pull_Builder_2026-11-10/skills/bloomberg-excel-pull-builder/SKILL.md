---
name: bloomberg-excel-pull-builder
description: Build Bloomberg Excel pull workbooks for ICE daily, BALMO and standard contracts or Platts assessment history, then freeze saved results to CSV. Use with the relevant ICE or Platts identifier skill when a user requests an actual refresh sheet or a reusable pull workflow.
---

# Bloomberg Excel pull builder

Deliver a real XLSX with native Bloomberg formulas, a counted request manifest and offline verification. Use the available spreadsheets skill for authoring and rendering. This skill defines construction; `ice-bbg-price-history` and `platts-bbg-price-history` own identifier resolution, listing rules and evidence. Read the applicable domain skill before producing formulas. Neither workbook preparation nor an offline check establishes live access.

## Build workflow

1. Inspect saved workbooks/CSVs before planning new requests. Retain the user-selected scope; distinguish history by observation date from a forward curve by delivery date. Generate the relevant domain CLI manifest and retain all dispositions, including rejected or discovery-only items.
2. Classify each operation using [instrument-rules.md](references/instrument-rules.md): ICE DAILY, BALMO, STANDARD generic/member, or PLATTS assessment. A daily historical frequency does not make a security an ICE DAILY contract. One workbook may contain several classes, on clearly labelled tabs.
   For a dated DAILY/BALMO contract's history, default to the requested full member-history range. A nominal-date diagonal is a distinct extraction choice, not the contract's entire history; derive it from saved full history when available. See the concrete member-history example in the instrument rules. If the domain CLI emits only a diagonal for a requested full history, retain that source manifest and record the explicit range-operation adaptation rather than silently presenting the diagonal as full history.
   For DAILY calendar coverage, identity boundaries, monthly observations or forward-strip diagnostics, also read [adapted-python-lessons.md](references/adapted-python-lessons.md). It distinguishes reusable data rules from xbbg-only settings and flags the untested Excel weekend case.
3. Read [workbook-construction.md](references/workbook-construction.md) and author the workbook using the spreadsheets workflow. Carry exact manifest identities and field choices into formulas; preserve uncertainty. Use fixed editable dates, manual calculation and zero extra controls by default. Keep vendor errors visible.
4. Count operations and review costs using [quota-and-state.md](references/quota-and-state.md). Count daily diagonals per distinct security/date, standard ranges per security/field, and discovery separately. No new vendor queries are needed to validate construction.
5. Inspect final OOXML and rendered sheets: formula routing, date bounds, operation counts, empty nonoverlapping spill areas, calc settings, labels and rejected items. Save a verification report and source/output hashes. Unsupported Bloomberg UDFs in an offline renderer are not live failures; never manufacture price caches.
6. Deliver the XLSX, manifest and concise count/status. Mark it PREPARED, not refreshed. Once the user has refreshed and saved it, use [freeze-saved-results.md](references/freeze-saved-results.md) to extract literal CSV without recalculation, then update study coverage and state from actual results.

## Completion criteria

For small single-field history workbooks (up to 40 operations), use the tested [helper workflow](references/helpers.md): `scripts/build_pull.mjs` builds from ICE/Platts manifests and `scripts/verify_pull.py` finalises and checks the new file. Larger consolidated layouts, discovery workbooks and multi-field output require the general construction workflow above. Do not silently drop operations to fit the helper.

The workbook exists and has been inspected; every vendor formula maps to a planned operation; field/security counts and discovery requests are disclosed; raw spill space is empty; dates are fixed and editable; errors are visible; unresolved mappings have no invented executable price formulas. Preserve the original refreshed source unchanged. Live execution requires the user's applicable authorization and a Bloomberg-capable environment; this skill itself provides no executor.

Installed companion skills are siblings under the skills root. If a required domain skill is unavailable, locate its kit source or report the missing dependency instead of guessing identifiers. The shared builder must not duplicate or override their mapping tables.

For WFJ/WFK full member histories, read [the sourced lifecycle/window rules](references/wfj-wfk-lifecycle.md) before setting dates. BALMO two-month listing breadth and DAILY 130-business-day breadth are different; retain historical expiry-version conflicts and label inferred buffers.
