"""Finalise a NEW offline-authored workbook, then verify request routing/spills.
Never use --finalize on a user-refreshed workbook. Standard library only.
"""
from pathlib import Path
import json,zipfile,xml.etree.ElementTree as E,hashlib,sys,re
N='http://schemas.openxmlformats.org/spreadsheetml/2006/main';Q='{'+N+'}'
def verify(folder,finalize=False):
 p=Path(folder);f=p/'Bloomberg_Trial.xlsx';receipt=json.loads((p/'build_receipt.json').read_text())
 with zipfile.ZipFile(f) as z:parts={n:z.read(n) for n in z.namelist()}
 root=E.fromstring(parts['xl/workbook.xml']);calc=root.find(Q+'calcPr')
 if finalize:
  assert receipt['status']=='PREPARED' and not receipt['executed']
  if calc is None:calc=E.SubElement(root,Q+'calcPr')
  calc.attrib.update(calcMode='manual',fullCalcOnLoad='0',forceFullCalc='0',calcOnSave='0');parts['xl/workbook.xml']=E.tostring(root,encoding='utf-8',xml_declaration=True)
  # Remove only offline-renderer UDF error caches on the newly authored anchors.
  for i,op in enumerate(receipt['operations'],2):
   name=f'xl/worksheets/sheet{i}.xml';s=E.fromstring(parts[name]);cell=next(c for c in s.iter(Q+'c') if c.get('r')==op['anchor']);v=cell.find(Q+'v')
   if cell.get('t')=='e' and v is not None:
    assert v.text in ('#NAME?','#VALUE!'),v.text
    cell.remove(v);cell.attrib.pop('t',None)
   parts[name]=E.tostring(s,encoding='utf-8',xml_declaration=True)
  with zipfile.ZipFile(f,'w',zipfile.ZIP_DEFLATED) as z:
   for n,b in parts.items():z.writestr(n,b)
 assert calc is not None and calc.get('calcMode')=='manual'
 def value(c):
  if c is None:return None
  if c.get('t')=='s':
   ss=E.fromstring(parts['xl/sharedStrings.xml']);return ''.join(ss[int(c.find(Q+'v').text)].itertext())
  if c.get('t')=='inlineStr':return ''.join(c.find(Q+'is').itertext())
  v=c.find(Q+'v');return v.text if v is not None else None
 count=0
 for i,op in enumerate(receipt['operations'],2):
  sheet=E.fromstring(parts[f'xl/worksheets/sheet{i}.xml']);cells={c.get('r'):c for c in sheet.iter(Q+'c')}
  assert value(cells.get('B4'))==op['security'];assert value(cells.get('B5'))==op['field']
  from datetime import date
  for address,key in [('B6','start'),('B7','end')]:assert int(float(value(cells[address])))==(date.fromisoformat(op[key])-date(1899,12,30)).days
  formula=cells[op['anchor']].find(Q+'f').text;assert '='+formula==op['formula']
  assert not re.search(r'TODAY|NOW|IFERROR',formula,re.I)
  for row in range(12,12+op['spill_rows']):
   for col in range(op['spill_columns']):
    address=chr(65+col)+str(row)
    if address==op['anchor']:continue
    c=cells.get(address)
    assert c is None or all(c.find(Q+x) is None for x in ('f','v','is')),address
  if op['scalar']:
   assert op['start']==op['end']
   nominal=re.search(r' (\d{8}) Comdty$',op['security'],re.I)
   if nominal:assert nominal[1]==op['start'].replace('-','')
  count+=1
 all_vendor=[]
 for n,b in parts.items():
  if re.fullmatch(r'xl/worksheets/sheet\d+\.xml',n):
   all_vendor += [e.text for e in E.fromstring(b).iter(Q+'f') if e.text and re.search(r'\b(?:BDH|BDP|BDS)\(',e.text)]
 assert len(all_vendor)==count==receipt['request_pairs']
 result={'PASS':True,'price_formulas':count,'extra_vendor_formulas':0,'manual_calculation':True,'routing_dates_spills':'PASS','live_execution':False,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
 (p/'VERIFICATION.json').write_text(json.dumps(result,indent=2));return result
if __name__=='__main__':print(json.dumps(verify(sys.argv[1],'--finalize' in sys.argv[2:])))
