"""Offline regression checks: run against an already verified PREPARED folder."""
import tempfile,shutil,zipfile,json,sys,xml.etree.ElementTree as E
from pathlib import Path
from verify_pull import verify,Q
source=Path(sys.argv[1]);assert verify(source)['PASS']
results={}
for mode in ('shifted_date','blocked_spill'):
 with tempfile.TemporaryDirectory() as t:
  p=Path(t);shutil.copy2(source/'Bloomberg_Trial.xlsx',p/'Bloomberg_Trial.xlsx');shutil.copy2(source/'build_receipt.json',p/'build_receipt.json')
  f=p/'Bloomberg_Trial.xlsx'
  with zipfile.ZipFile(f) as z:parts={n:z.read(n) for n in z.namelist()}
  # Standard range is operation 2 in the saved ICE trial.
  name='xl/worksheets/sheet3.xml';s=E.fromstring(parts[name])
  if mode=='shifted_date':
   c=next(c for c in s.iter(Q+'c') if c.get('r')=='B6');c.find(Q+'v').text='46000'
  else:
   sd=s.find(Q+'sheetData');r=next((r for r in sd if r.get('r')=='13'),None)
   if r is None:r=E.SubElement(sd,Q+'row',r='13')
   c=next((c for c in r if c.get('r')=='B13'),None)
   if c is None:c=E.SubElement(r,Q+'c',r='B13')
   E.SubElement(c,Q+'v').text='123'
  parts[name]=E.tostring(s)
  with zipfile.ZipFile(f,'w') as z:
   for n,b in parts.items():z.writestr(n,b)
  try:verify(p)
  except AssertionError:results[mode]='REJECTED_AS_EXPECTED'
  else:raise AssertionError('Verifier missed '+mode)
print(json.dumps(results))
