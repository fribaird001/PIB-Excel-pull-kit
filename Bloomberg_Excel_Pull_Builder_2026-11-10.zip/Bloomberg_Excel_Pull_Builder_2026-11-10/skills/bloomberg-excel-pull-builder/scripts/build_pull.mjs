// Offline manifest-to-workbook builder. Invoke through the bundled Node runtime.
import fs from 'node:fs/promises';import path from 'node:path';import {createRequire} from 'node:module';import {pathToFileURL} from 'node:url';
const [manifestFile,outputDir,runtimeModules,evidenceFile]=process.argv.slice(2);
if(!runtimeModules)throw Error('Usage: build_pull.mjs manifest.json NEW-output-dir runtime-node_modules [saved-identity-evidence.json]');
const require=createRequire(path.join(path.resolve(runtimeModules),'_loader.cjs'));
const {Workbook,SpreadsheetFile}=await import(pathToFileURL(require.resolve('@oai/artifact-tool')).href);
const manifest=JSON.parse(await fs.readFile(manifestFile,'utf8'));
if(manifest.execution_performed||!['OK','PARTIAL','DISCOVERY_REQUIRED'].includes(manifest.outcome))throw Error('Unsupported manifest state');
const evidence=evidenceFile?JSON.parse(await fs.readFile(evidenceFile,'utf8')):null;
const operations=(manifest.operations||[]).map(o=>o.platts_id?{...o,kind:'history',securities:[o.security],fields:[o.field],options:{excel:[]},ice_codes:[o.platts_id],note:o.description+'; '+o.evidence,excel:o.formula}:o);const omissions=operations.filter(o=>o.kind!=='history');
if(omissions.some(o=>o.kind==='identity')&&!evidence)throw Error('Identity omission requires explicit saved evidence; pass evidence JSON or handle identity stage separately');
const selected=operations.filter(o=>o.kind==='history');if(!selected.length)throw Error('No history operations; discovery must be completed separately');
if(selected.length>40)throw Error('Small-workbook helper limit is 40 history operations; use a consolidated raw layout for larger plans');
const plan=[];
for(const op of selected){
 if(op.securities?.length!==1||op.fields?.length!==1)throw Error('This helper supports one security/field per operation; split an accepted manifest explicitly');
 if(!/^\d{4}-\d{2}-\d{2}$/.test(op.start)||!/^\d{4}-\d{2}-\d{2}$/.test(op.end)||!Number.isFinite(Date.parse(op.start))||!Number.isFinite(Date.parse(op.end))||op.start>op.end)throw Error('Invalid dates');
 const opts=op.options?.excel||[];const scalar=opts.includes('Dts=H');
 if(scalar&&op.start!==op.end)throw Error('Scalar diagonal must have equal dates');
 const nominal=op.securities[0].match(/ (\d{8}) Comdty$/i);
 if(scalar&&nominal&&nominal[1]!==op.start.replaceAll('-',''))throw Error('Diagonal observation date differs from embedded nominal date');
 plan.push({security:op.securities[0],field:op.fields[0],start:op.start,end:op.end,options:opts,scalar,note:op.note||'',code:(op.ice_codes||[]).join(','),source_formula:op.excel});
}
await fs.mkdir(outputDir,{recursive:false});
const w=Workbook.create();const c=w.worksheets.add('Control');
function base(s){s.showGridLines=false;s.getRange('A1:F28').format.font={name:'Arial',size:11,color:'#20364D'};s.getRange('A1:A28').format.columnWidth=20;s.getRange('B1:B28').format.columnWidth=48;s.getRange('C1:F28').format.columnWidth=22;s.getRange('A1:F28').format.rowHeight=24;}
base(c);c.getRange('A1:A28').format.columnWidth=28;c.getRange('C1:C28').format.columnWidth=38;c.getRange('A2').values=[['Bloomberg history pull']];c.getRange('A2:F2').format.font={size:16,bold:true,color:'#19324D'};
c.getRange('A4:B9').values=[['Status','PREPARED — not executed'],['BDH formulas',plan.length],['Extra BDP/BDS formulas',0],['Action','Refresh this workbook once; wait; save.'],['Dates','Fixed per request; edit on each raw tab.'],['Scope','Historical sample; saved identity/chain evidence reused.']];
c.getRange('A11').values=[['Raw errors must remain visible. Save before asking for frozen CSV export.']];
c.getRange('A13').values=[['Omitted non-history operations: '+omissions.length+'; see build_receipt.json.']];
c.getRange('A15:F15').values=[['Sheet','ICE code','Security','Field','Start','End']];c.getRange('A15:F15').format={fill:'#19324D',font:{bold:true,color:'#FFFFFF'}};
for(let i=0;i<plan.length;i++){
 const p=plan[i];const name=`Pull_${i+1}`;const s=w.worksheets.add(name);base(s);p.sheet=name;p.anchor='A12';
 s.getRange('A2').values=[[p.code+' | '+(p.scalar?'dated diagonal':'member / series range history')]];s.getRange('A2:F2').format.font={size:15,bold:true};
 s.getRange('A4:A9').values=[['Security'],['Field'],['Start'],['End'],['Mode'],['Note']];
 const serial=d=>(Date.parse(d+'T00:00:00Z')-Date.UTC(1899,11,30))/86400000;
 s.getRange('B4:B9').values=[[p.security],[p.field],[serial(p.start)],[serial(p.end)],[p.scalar?'Scalar: start = end':'Date/value range'],[p.note.length>150?'Saved source evidence reused. Full provenance is in build_receipt.json.':p.note]];
 s.getRange('B6:B7').setNumberFormat('yyyy-mm-dd');s.getRange('B6:B7').format.fill='#FFF1C9';s.getRange('B9:F10').merge();s.getRange('B9').format.wrapText=true;
 s.getRange('A11:B11').values=[[p.scalar?p.field+' (nominal date above)':'Date',p.scalar?'':p.field]];s.getRange('A11:B11').format={fill:'#19324D',font:{bold:true,color:'#FFFFFF'}};
 p.formula='=_xll.BDH($B$4,$B$5,$B$6,$B$7'+p.options.map(x=>','+JSON.stringify(x)).join('')+')';s.getRange(p.anchor).formulas=[[p.formula]];
 if(!p.scalar)s.getRange('A12:A28').setNumberFormat('yyyy-mm-dd');
 c.getRange(`A${16+i}:F${16+i}`).values=[[name,p.code,p.security,p.field,p.start,p.end]];
 p.spill_rows=p.scalar?1:Math.ceil((Date.parse(p.end)-Date.parse(p.start))/86400000)+4;p.spill_columns=p.scalar?1:2;
}
w.recalculate();await(await SpreadsheetFile.exportXlsx(w)).save(path.join(outputDir,'Bloomberg_Trial.xlsx'));
await fs.writeFile(path.join(outputDir,'build_receipt.json'),JSON.stringify({manifest:path.resolve(manifestFile),status:'PREPARED',executed:false,identity_evidence:evidence,operations:plan,omitted_operations:omissions,request_pairs:plan.length},null,2));
for(const name of ['Control',...plan.map(x=>x.sheet)]){const b=await w.render({sheetName:name,range:name==='Control'?'A1:F21':'A1:F16',scale:1,format:'png'});await fs.writeFile(path.join(outputDir,name+'.png'),new Uint8Array(await b.arrayBuffer()));}
console.log(JSON.stringify({outputDir,price_formulas:plan.length,extra_requests:0}));
