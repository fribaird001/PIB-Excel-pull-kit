# Freeze saved results without another pull

Read cached workbook results using ZIP/XML or a cache-only reader; never launch Excel, recalculate, or execute Bloomberg to export. Keep source bytes unchanged and hash before/after. Compare saved formula identities and edited dates with the prepared manifest: users may have changed them. Record discrepancies instead of attaching the old plan blindly.

For range history, inspect each known raw spill block, identifying date/value columns and actual returned fields. For daily diagonals, use the nominal date and its scalar cached result; do not interpret the security's embedded date as a returned observation timestamp. Include request class and both dates where available. Distinguish missing formula caches from genuine empty provider results and pending Requesting Data text.

Normalise Excel datetime/date cells and serial dates in known date columns using the workbook's 1900/1904 epoch. Validate against actual request bounds, retain raw date representation, and flag ambiguity. Preserve raw numeric XML strings where possible; reject booleans and nonfinite values as prices. Keep error codes, text responses, blanks and pending results in a separate audit table rather than coercing to zero. Native sparse dates remain sparse.

Output formula-free CSV with domain ID, security, field, observation date, nominal/delivery date when relevant, value, source workbook/sheet/cell and retrieval time if known. Keep raw values as data, not executable spreadsheet formulas. Export untrusted text safely if users may open audit CSVs in Excel, retaining the original text in a non-executing provenance representation.

Check uniqueness on exact security+field+observation date (include nominal contract identity for diagonals). Preserve overlapping conflicts and source vintages rather than silently choosing one. Report observations, first/last dates, errors and suspected gaps per series; first/last endpoints do not prove complete coverage. Hash outputs and create a coverage index. Preserve old frozen archives; merge into a new version with explicit overlap decisions.

Only then update the study cut and recompute the analyses actually supported by the new data. Identify which models were rerun, separate reconciliation from causal evidence, and retain missing dates and errors. Do not claim a complete study refresh when only coverage/arithmetic checks were rerun.
