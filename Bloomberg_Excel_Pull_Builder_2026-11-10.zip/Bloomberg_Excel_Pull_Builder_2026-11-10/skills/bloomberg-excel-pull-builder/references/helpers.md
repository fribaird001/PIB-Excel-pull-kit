# Tested helper source

The scripts are offline; they contain no vendor executor. Runtime: bundled Node with @oai/artifact-tool and Python standard library. Locate runtime dependencies through load_workspace_dependencies. Run the spreadsheet creation marker once before authoring, as required by the spreadsheets skill.

```text
node scripts/build_pull.mjs manifest.json NEW-output-directory runtime-node_modules [identity-evidence.json]
python scripts/verify_pull.py output-directory --finalize
python scripts/verify_pull.py output-directory
```

Use the actual absolute runtime paths; these examples show argument order, not shell quoting. The builder refuses an existing output directory. It accepts ICE manifests with history operations, or Platts manifests with platts_id/security/field/formula. Each operation must have one exact security and field. Up to 40 operations, one isolated raw sheet per operation. Dates are numeric Excel serials with yyyy-mm-dd formatting, not JS Date objects (the trial exposed text-date export).

ICE BDP identities are not silently executed. To omit them, supply a JSON file containing the saved evidence source, hash, basis and product scope; review that it covers the omitted identities. The receipt retains omitted operations and evidence. New contradictory evidence still requires the domain investigation. Discovery-only manifests stop: build/refresh the discovery stage separately and feed accepted member evidence back into the ICE CLI. The price helper emits no BDS or BDP, preserving the zero-extra-request default.

The verifier checks final raw formulas, security/field cells, numeric request dates, equal dates for diagonals, empty reserved spills, vendor counts and manual calculation. --finalize sets manual calc metadata and removes offline-renderer unsupported-UDF caches on the new anchors only. Never run --finalize on a workbook after a user refresh: use a saved-result extractor instead. The helper's raw labels and source receipt are retained; it does not freeze prices or certify live access.

Full multi-field requests, a large consolidated daily grid, arbitrary BDP/BDS workflows and frozen CSV extraction use the main reference workflow rather than this limited helper. Source manifests, receipts and errors remain reviewable. Update the helper only after reproducing a concrete unsupported case.

Trial 2026-11-10: healthy ICE kit; WFJ DAILY 2026-10-01/02, WFK BALMO member from bundled ICE_PULL!R4, and JFG standard HCEA history. Four raw price formulas, zero new controls/discovery. HCE resolves as a root in lookup but manifest requires JFG (ICE code). Existing identity/chain evidence reused, not revalidated live. User Excel refresh/save is required to establish returned prices.
