# Adapting the reusable Python engines to Excel

Reviewed 10 November 2026, read-only sources under:
`C:/Users/tankkh/OneDrive - YTL PowerSeraya/Desktop/GH_repo/cps-checkpoints/DFL_ASKB_DATACOMPLETION/reusable_code`

Sources: README.md; dailytickers/{lessons_learnt.md,explain.md,daily_dated_pull.py}; monthlytickers/lessons_learnt.md; forwardcurve/{lessons_learnt.md,forward_curve_pull.py}; askb_codex/lessons_learnt.md. No source engine was changed or executed. The recommendations below distinguish saved local observations from verified Excel behaviour.

## Include directly or adapt

| Lesson | Existing coverage / change | Excel application |
|---|---|---|
| Nominal-date diagonal, never last nonblank | Already covered; helper strengthened | A dated daily/BALMO diagonal must use start=end=embedded nominal date. Full member lifecycle history is a separately labelled range. |
| Identity start differs from populated settlement start | Added explicitly | Valid ticker with empty early prices is not automatically a failed request. Record identity boundary, first price and last price separately. Preserve missing values; investigate before classifying empty as expected. |
| Daily enumeration includes weekends | New qualification | Do not silently drop weekends for every DAILY family. The source enumerates calendar days; the ICE CLI currently enumerates weekdays. Record the difference and disclose untested/unrequested dates before claiming a complete strip. |
| Exact requested-versus-resolved guard | Added explicitly | Reuse saved identity evidence by exact security. New conflicting identities require investigation. Dated-family SECURITY_DES matching is a family-specific guard, not a universal equality test for a rolling generic whose description may name its active member. |
| Responses can reorder | Added explicitly | Join saved output, BDS members and identity evidence by exact requested ticker/field/date or known raw anchor; never attach descriptions by row position after reordering. |
| Monthly prints must not be step-filled | Already covered; clarified | Native monthly observations stay monthly. Any mean/last reduction belongs in a separate analysis with a stated rule, not vendor fill settings. Default one-field raw BDH does not force a monthly periodicity override. |
| Year width differs by family | Already covered | Use accepted CLI/chain members; no global one-digit/two-digit year synthesis. |
| Generic history versus forward snapshot | Already covered; clarified | Rolling generic BDH is history. A forward snapshot uses distinct accepted dated members at one as-of time/date; BDP gives a current snapshot, BDH gives specified observation dates. Do not present current BDP as a historical snapshot. |
| Missing bids/asks can be normal | Added explicitly | PX_LAST/PX_SETTLE may exist while PX_BID/PX_ASK do not. Report field-specific coverage, not whole-security failure or invented quotes. Add only fields needed for the task. |
| Flat-curve guard | Added with qualification | Repeated identical values across tenors trigger an identity/source review, not proof of a false curve. Genuine curves can be flat; differing values alone do not certify correct instruments. Fewer than two populated tenors is insufficient. |

## Keep Python-specific

- `Days='A'` fixed empty daily frames in the recorded xbbg environment. The verified weekday Excel specimen uses `Days=W`; do not transpose option spelling or calendar semantics across lanes. A weekend Excel case still needs a targeted live test. Preserve an empty response as evidence rather than blindly changing options or increasing the date window.
- Narwhals `.to_pandas()` and long/wide DataFrame normalisation belong in a Python adapter, not Excel formulas. Their transferable principle is explicit output shape and exact-key joins.
- `Per='CM'` caused a recorded xbbg error on CKTJJCC. This is not proof of an Excel failure with every periodicity option. Retrieve native observations by default and apply deliberate reductions offline; test any required override on the actual instrument/lane.
- Python imports, unittest sys.path, dependency injection for the ASKB CLI reader and notebook ZIP/download workarounds are outside the Excel builder's task. Retain them in their original code/governance.
- A historical multi-file apply_patch failure is a tooling incident, not a Bloomberg or workbook rule. Do not encode a universal one-file-per-patch restriction.

## Explicitly reject unsafe transfer

The forward engine's empty-chain fallback defaults to guessed year width. Do not import it into the builder: missing chain/listing evidence stays unresolved/discovery-required. Likewise, flat-curve diagnostics and successful identity do not independently establish economic correctness, full history coverage or contractual entitlement.

## Remaining live test

The four-formula trial covers two weekday DAILY observations, one saved BALMO member diagonal and one standard generic history. It has not validated weekend calendars, a new family, current access, or returned prices. A weekend test should be separately scoped and counted with an evidence-backed exact weekend member; do not add it silently to the user's workbook or claim the existing sample proves it.
