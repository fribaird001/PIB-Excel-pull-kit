# WFJ/WFK member-history window rules — 10 November 2026

Separate (1) exact member identities/nominal dates from (2) historical observation dates. Full history uses one range BDH per member; a realised diagonal is an optional later filter. Do not use a forward member-selection horizon as the BDH observation range.

WFK BALMO: current ICE product specification https://www.ice.com/products/83035214 says up to two consecutive months; last trading second business day after nominal date. For the verified 20261001 member the revised retrieval window is 2026-09-01 through 2026-10-30: prior calendar-month start through nominal-month end. This is an explicit buffered planning window, not proof of first listing/first price. The end deliberately includes the older specification's month-end possibility. If saved prices touch the start boundary, review evidence for expansion rather than certify complete history.

WFJ DAILY: https://www.ice.com/products/83035213/Wet-Freight-Dirty-FFA-Daily-Cross-UKC-Platts-Mini-Future says up to 130 consecutive business days, second business day after nominal date, with business days defined by Platts Dirty Tankerwire publication. For verified 20261001 use 2026-03-25 through 2026-10-30: a weekday lookback plus margin and an end buffer. This is not an exact 130-publication-day calendar calculation. Use actual listing/price evidence and publication holidays to certify lifecycle coverage; do not generalise a two-month lookback to DAILY or to other daily families.

Version conflict: ICE launch specification https://www.ice.com/publicdocs/circulars/23076_attach_4.pdf (2023), WFK page 3, says last trading day of contract month, unlike current WFK product page. Do not apply current expiry retrospectively without effective-date evidence. Neither source establishes Bloomberg first-price date or guarantees cache population after expiry. A returned post-expiry value is retained and labelled, not treated as new tradable history.

Two raw PX_SETTLE range formulas, zero controls, fixed editable numeric Excel dates, no live requests executed. Days=W is the recorded Excel weekday recipe; weekend completeness unverified. Full-history helper spills are sized by the actual requested observation interval. This workbook supersedes the broad January-start example for this test. Exact first/last observations remain pending user refresh/save. Native errors and missing values remain visible.

Evidence hierarchy: saved member-level lifecycle/price evidence, then effective-dated exchange rules, then disclosed buffered planning bounds. Up to N listed members does not prove exactly N days of history. No universal date-minus-5-plus-2-months rule was found. No original refreshed workbook has been rewritten.


## Saved Bloomberg test — 10 November 2026

Source corrected_member_windows_2026-11-10/sheet/Bloomberg_Trial.xlsx, SHA256 a2a8190fac7ae0147a36e42a921f894a5b2f7574ddb240aa6566ef1e78dc0a5a; cached results inspected without recalculation. WFKBALMO 20261001: 44 numeric observations, 2026-09-01 (21.834) through 2026-10-30 (60.1195). WFJDAILY 20261001: 134 numeric observations, 2026-03-31 (15.9262) through 2026-10-05 (43.85). These empirically confirm multi-date histories for both examples.

BALMO prices touch BOTH requested boundaries: earliest history is not established and the September start must not be certified complete. Returned October observations extend beyond nominal+2 weekdays; retain them and investigate the historical expiry/version or vendor-series semantics before asserting a hard nominal-date cutoff. DAILY's observed end is consistent with nominal+2 weekdays for this member, but one member is not a universal family rule. Observation counts are saved prices, not quota hits. No new query is authorised or executed by this review.
