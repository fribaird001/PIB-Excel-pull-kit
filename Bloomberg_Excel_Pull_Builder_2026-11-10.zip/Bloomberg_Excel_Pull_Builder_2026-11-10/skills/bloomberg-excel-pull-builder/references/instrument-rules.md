# Instrument rules

These rules assemble Excel requests from accepted domain manifests. Read the ICE skill's `references/formulas.md`, `traps.md` and `workbook-build.md` for ICE-specific cases. Those references include historical specimen formulas, not instructions to add its probes or negative controls to every new workbook.

## ICE DAILY: dated diagonal

Use the CLI-confirmed DAILY class and root. The family can differ from the ICE code (the known WFJ/DFO examples use WFJDaily/DFODaily); never append Daily to a guessed root. For each approved nominal date, the manifest supplies the dated security `<validated family> <YYYYMMDD> Comdty`. Restrict enumeration to the requested window and applicable calendar. A weekday axis does not model exchange holidays.

The local Python engine enumerates all calendar dates, whereas the installed ICE CLI's current history planner uses weekdays. A weekday-only manifest is not evidence that weekend contracts do not exist. Declare the enumerated calendar and coverage limitation; use evidence-backed weekend members and a targeted Excel calendar test if complete calendar-day coverage is required. The sample validates weekdays only. Identity inception and settlement inception are separate boundaries; empty early prices need classification, not filling.

One dated security per row, one scalar observation on its nominal date:

```excel
=_xll.BDH($B13,$C13,$A13,$A13,"Dts=H","Days=W","Fill=N/A")
```

Here A is the nominal date, B the exact manifest security, C the field (normally PX_SETTLE for this ICE workflow). Gate unused rows on a nonblank date and an offline manifest disposition permitting a price operation; use existing root evidence instead of adding repeated NAME requests. DAILY diagonals are the deliberate exception to one-range-per-series: dates identify different contracts. A range over one dated contract cannot replace all dated members. Missing dates remain missing.

For the separate xbbg lane the installed ICE engine uses `Days='A'` and keeps only observation date equal to nominal date. Do not transplant that option into this verified Excel diagonal recipe. Follow the domain skill's programmatic approval/staging rules if switching lanes.

## ICE BALMO: discover, then build member pulls

BALMO shares a date-stamped member shape with DAILY, but membership is not generated from a calendar. Use accepted saved FUT_CHAIN evidence first. Without it, deliver a discovery-only stage using the domain CLI's exact generic:

```excel
=_xll.BDS($B$4,"FUT_CHAIN","INCLUDE_EXPIRED_CONTRACTS=Y","CHAIN_DATE=20260401")
```

The date is an example of a fixed discovery setting, not a universal chain date. Record requested chain date and actual retrieval time. A returned chain is evidence of returned members, not proof of complete all-time membership. Pass saved members into `bbg manifest ... --balmo-members members.json` with schema_version, product ICE code, discovery_security/date, source_description and member list as specified by the ICE skill.

Use exact returned strings, including spacing and case. A valid generic NAME is not evidence that its price history exists. Without member evidence retain DISCOVERY_REQUIRED and emit no invented member BDH. Once validated, choose the requested meaning:

- **Diagonal settlement series:** one observation at each member's nominal date, using the DAILY scalar pattern. Label this as the engine's diagonal extraction.
- **History of an individual BALMO member:** one range BDH on that exact member and the requested observation dates, with a separate date/value spill block. Label its nominal/delivery date separately.

The diagonal is not the full lifecycle history. Do not replace BALMO prices with a mean of daily prices unless the user explicitly wants a separate analytical proxy; partial live-window averages are not final settlement.

### Example: full dated-member history versus a diagonal

If the user asks for a DAILY or BALMO contract's history, default to its full requested observation-date range. Use a diagonal only when the user requests a realised nominal-date series or explicitly selects that extraction. Establish the intended output shape before treating a diagonal as complete coverage of a dated family.

Suppose saved chain evidence confirms `WFKBALMO 20261106 Comdty` (the embedded date means 6 November 2026, in YYYYMMDD format). Put that exact security in B4, PX_SETTLE in B5, and fixed numeric Excel dates 2026-10-01 and 2026-11-09 in B6/B7:

```excel
=_xll.BDH($B$4,$B$5,$B$6,$B$7,"Dts=S","Days=W","Fill=N/A")
```

This asks for the member's observation-date history over the range, including dates before or after its nominal date where the provider has observations. It does not assume the member traded throughout that window or promise a particular count. Reserve a date/value spill block and retain every returned date, sparse value and error. The exact member above is illustrative until its chain evidence is supplied; do not generate it merely from the calendar.

For a verified DAILY member, use the same range-history shape with its exact accepted security. A DAILY family label does not force one-date retrieval. The Days=W option is the recorded weekday Excel recipe; complete weekend/calendar coverage remains a separate unverified case, not a guarantee of all possible observations.

If a realised diagonal is also wanted, freeze the full member history first and select only the row whose observation date equals 2026-11-06. Missing that date means a missing diagonal observation; do not choose the last populated date instead. No additional vendor query is necessary to derive this subset. Across many members, repeat that filter per exact member and nominal date. Keep the full member-history archive alongside the derived diagonal.

The reusable Python daily engine requests a history grid and then deliberately filters it in `select_nominal_diagonal()`. That filtering is an analytical choice, not evidence that dated DAILY/BALMO securities have only one historical price. The four-formula Excel trial exercised the diagonal choice for those two classes; it did not test their full lifecycle histories.

## ICE STANDARD: generic history or explicit delivery contracts

- Generic history: one range on the exact accepted active/generic security. It is rolling history, not a fixed delivery contract or a tenor ladder.
- Explicit contract history: one range per accepted delivery month, with listing/expiry status retained. Resolve via `bbg ticker`/`manifest`; use the domain CLI's exact month/year string. `FGHJKMNQUVXZ` is the month alphabet, but it does not establish root, year width or listing.
- Month generics such as ROOT+MMM+N roll to the next unexpired contract of that calendar month. They are not a fixed-year historical contract.

```excel
=_xll.BDH($B$4,$B$5,$B$6,$B$7,"Dts=S","Days=W","Fill=N/A")
```

Standard ICE normally uses PX_SETTLE; use another field only when the manifest/task calls for it. Multiple fields require wider spills and count as multiple security/field pairs. Retain LISTING_UNKNOWN, EXPIRY_UNKNOWN, NOT_LISTED, T4 and DISCOVERY_REQUIRED; respect the domain skill's partial-strip hold. No synthetic executable ladder for unresolved months.

For an expired member's final settlement, reuse an already saved last-tradeable date when available. Otherwise explicitly plan a BDP LAST_TRADEABLE_DT on the explicit member, then a one-date BDH at that date. Accept numeric dates or parse date text with a declared locale; preserve ambiguous/error dates for review. BDP PX_SETTLE on an expired member can be unavailable. Do not silently substitute the generic or delivery-month end.

## PLATTS: assessment history, including daily and rolling tenors

Use `platts-bbg manifest` and exact assessment IDs as joins. Typical recipe:

```excel
=_xll.BDH($B$4,$B$5,$B$6,$B$7)
```

One anchored raw PX_LAST range per exact Bloomberg assessment security, with a two-column date/value block. The map's Index suffix is an empirical recipe default. A Platts daily assessment, Wk01, Mo01 or Day-N is not an ICE dated contract. Never manufacture month-letter contracts or date-stamped daily tickers from Platts IDs.

Retain native sparse calendars and discontinued endpoints. Monthly averages are published observations; requesting every calendar day does not create daily underlying prices. Read the current eligible/access evidence rather than treating historical/count-only success as current access or contractual entitlement. Day-N programme launch and individual endpoints belong to the domain map/evidence, not a universal start date in the builder.
