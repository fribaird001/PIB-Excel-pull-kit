# Workbook construction and verification

Use the spreadsheet-authoring skill and its bundled dependencies. Inspect an existing user-approved workbook when matching its design. Build a new output; avoid re-saving refreshed evidence through a general-purpose workbook library because caches, Bloomberg metadata and user annotations may be lost.

## Layout

- Control: fixed editable start/end, field choices, archive cut, planned counts by class, preparation status, refresh/save instructions. Default to the last completed required observation session, not an assumed host date. Avoid TODAY/NOW date drivers by default.
- Manifest: exact domain ID, Bloomberg security, class, field, start/end, nominal/delivery date if relevant, disposition, evidence source, output sheet/anchor, operation stage. Separate price operations from BDP/BDS discovery.
- Raw history tabs: one anchor per request with labelled security, ID, dates and field above it; pair date/value columns with a blank gutter. Multiple fields use one date plus all returned field columns. Reserve enough rows for the entire requested calendar window plus Bloomberg output headers; partition wide/large workbooks before Excel's row/column limits.
- Daily diagonal tabs: nominal date, exact dated security, field and scalar raw result per row. Keep nominal dates distinct from retrieval time and observation date. Do not populate inactive tail rows with executable vendor calls.
- Discovery tabs when needed: isolated BDS spills and saved evidence provenance; no guessed downstream member prices. Save/rebuild the price stage from verified results.
- Optional analysis tabs use raw/frozen results and are clearly distinct from retrieval. Do not force the historical ICE specimen's eight tabs into an unrelated task.

Native file formulas use the verified `_xll.BDH`, `_xll.BDP`, `_xll.BDS` form. Avoid COUNT(BDH) as a substitute for raw prices and IFERROR that conceals vendor errors. Preserve documented warm-up NA() in analytical models. `Headers=False` and `Dates=False` failed in the recorded ICE environment; use the domain-supported date-output options.

Set calculation to manual and disable fullCalcOnLoad, forceFullCalc and calcOnSave when supported. These are mitigations, not a guarantee against add-in background refresh. Instruct the user to refresh the intended workbook/portion once, wait for requests to finish, then save. Do not make Ctrl+Alt+F9 across all open workbooks the default.

## Offline checks before handoff

Read final ZIP/XML without opening Excel. Check:

1. Each vendor formula corresponds to its planned operation and exact security/field/date references. Deduplication must preserve deliberately different ranges/fields. Formula count alone does not equal security/field count for multi-field requests.
2. Start <= end; DAILY scalar start=end=nominal date. All nominal dates are within the selected enumeration and listing scope. BALMO member strings have source evidence.
3. Expected date/value spill rectangles are empty apart from the anchor; no table, merged cell, neighbouring output or cached demonstration value blocks them. Long histories reserve calendar-day capacity, not just assumed trading-day counts.
4. Manual calc metadata, absence of unplanned volatile date drivers/vendor controls, and visible dispositions. A displayed planned count is not evidence of execution.
5. Render Control and every distinct raw layout; check label clipping, date formats, spill separation and readable counts. Offline engines cannot execute Bloomberg UDFs. A renderer's #NAME? is not a provider response. If clearing renderer-generated error caches, operate only on the new unsent workbook, preserve every formula, and reverify the final OOXML; never clear real saved vendor errors.
6. Save verification with planned operations by type, security/field pairs, unique securities by category, calc settings, executed=false and output SHA256. Retain the exact source manifest alongside the XLSX.

If preparation fails, keep the manifest and report the concrete failure. A ticker CSV or formula text file alone does not complete a request for an Excel refresh workbook.
