# Quota planning and resume state

Use the Platts skill's `references/pull-cost-and-quota.md` and companion verification reference for the saved research, source dates and limitations. Those explain Bloomberg quota accounting, not direct Platts API charges. Reverify current provider policy if asked for current contractual limits; no account ceiling is established by this skill.

Track separately:

| Quantity | Meaning |
|---|---|
| Vendor formulas | Planned BDH/BDP/BDS anchors; discovery separated |
| Security/field executions | Daily documented accounting model; repeats/retries add executions |
| Monthly unique securities/category | Different dated members are different securities; historical range length is not a multiplier under saved guidance |
| Returned numeric prices | Archive volume, not measured quota debit |
| Actual refresh count | Unknown until observed/reported; saved cache alone cannot reconstruct every attempt |

Example: 16 Platts single-field histories over 20 years are 16 planned pair executions once, not 16 times the number of dates. Two ICE DAILY products over 100 nominal dates can mean 200 distinct dated securities and 200 one-field price operations. A two-field range is one formula but two security/field pairs. Count chain/identity/expiry requests explicitly; do not assume their category weighting equals BDH.

Reuse saved evidence; request uncovered dates and repair justified gaps. Splitting history windows is not inherently quota-saving. Batching can manage breadth, review and file size. The 3,500 concurrent real-time field restriction is not a history batching allowance. Add zero controls by default; reuse prior identity evidence unless new contradictory evidence or an explicit audit requires investigation. Respect the ICE CLI's mandatory discovery/status gates.

Keep state.md beside the deliverables: scope, manifest/output paths and hashes, planned counts, exclusions, archive cut, PREPARED / USER_SAVED / FROZEN / STUDY_UPDATED stage, known actual executions, errors and next action. Update progress only from observed evidence. Never describe a prepared workbook as refreshed or infer remaining allowance by subtracting an old speculative baseline.
