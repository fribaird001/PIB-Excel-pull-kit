# Formulas — verbatim (`bdh_ice_path.xlsx`, 2026-10-25 refresh (data through 2026-10-22))

> Generated programmatically from `xl/worksheets` XML — not typed. Regenerate with
> `python tools/extract_formulas.py`. Never copy these into a *refreshed* workbook: the
> specimen is source-of-truth and its cached values are part of the evidence.

## Root registration + gates (live NAME checks)

### Tickers!G4 — WFJ root

```excel
(constant/origin cell) WFJDaily
```
cached value/type: `WFJDaily` (s)

### Tickers!G5 — WFK root

```excel
(constant/origin cell) WFKBalmo
```
cached value/type: `WFKBalmo` (s)

### Tickers!G6 — JFG root

```excel
(constant/origin cell) HCE
```
cached value/type: `HCE` (s)

### Tickers!G7 — DFO root

```excel
(constant/origin cell) DFODaily
```
cached value/type: `DFODaily` (s)

### Tickers!G8 — WNC root

```excel
(constant/origin cell) ATO
```
cached value/type: `ATO` (s)

### Tickers!J4 — gate WFJ

```excel
=
IF(OR(ISERROR(I4),LEFT(I4&"",1)="#"),"NO","YES")
```
cached value/type: `YES` (str)

### Tickers!J7 — gate DFO

```excel
=
IF(OR(ISERROR(I7),LEFT(I7&"",1)="#"),"NO","YES")
```
cached value/type: `YES` (str)

## Date axis

### ICE_PULL!A13 — first weekday

```excel
=
DATE(2026,4,1)
```
cached value/type: `46113` (numeric)

### ICE_PULL!A14 — WORKDAY progression

```excel
=
IF(A13="","",IF(WORKDAY(A13,1)>DATE(2026,10,23),"",WORKDAY(A13,1)))
```
cached value/type: `46114` (numeric)

## Daily dated assembly + one-date BDH

### ICE_PULL!A6 — identity probe (first nominal date)

```excel
=
Tickers!$G$4&" "&TEXT($A$13,"yyyymmdd")&" Comdty"
```
cached value/type: `WFJDaily 20260401 Comdty` (str)

### ICE_PULL!B13 — WFJ diagonal pull

```excel
=
IF(OR($A13="",Tickers!$J$4<>"YES"),"",_xll.BDH(Tickers!$G$4&" "&TEXT($A13,"yyyymmdd")&" Comdty","PX_SETTLE",$A13,$A13,"Dts=H","Days=W","Fill=N/A"))
```
cached value/type: `41.76` (numeric)

### ICE_PULL!C13 — DFO diagonal pull

```excel
=
IF(OR($A13="",Tickers!$J$7<>"YES"),"",_xll.BDH(Tickers!$G$7&" "&TEXT($A13,"yyyymmdd")&" Comdty","PX_SETTLE",$A13,$A13,"Dts=H","Days=W","Fill=N/A"))
```
cached value/type: `40.435899999999997` (numeric)

## Generic roots — whole history in one call

### ICE_PULL!A7 — HCE1 probe target string

```excel
=
Tickers!$G$6&"1 Comdty"
```
cached value/type: `HCE1 Comdty` (str)

### ICE_PULL!E12 — HCE1 history

```excel
=
_xll.BDH(Tickers!$G$6&"1 Comdty","PX_SETTLE",DATE(2026,4,1),DATE(2026,10,23),"Dts=S","Days=W","Fill=N/A")
```
cached value/type: `46113` (numeric)

### ICE_PULL!H12 — ATO1 history

```excel
=
_xll.BDH(Tickers!$G$8&"1 Comdty","PX_SETTLE",DATE(2026,4,1),DATE(2026,10,23),"Dts=S","Days=W","Fill=N/A")
```
cached value/type: `46113` (numeric)

### ICE_PULL!A9 — ATO1 probe target string

```excel
=
Tickers!$G$8&"1 Comdty"
```
cached value/type: `ATO1 Comdty` (str)

## BALMO: identity then chain (never assemble)

### ICE_PULL!A5 — WFKBalmo1 probe target

```excel
=
Tickers!$G$5&"1 Comdty"
```
cached value/type: `WFKBalmo1 Comdty` (str)

### ICE_PULL!B5 — BDP TICKER

```excel
=
_xll.BDP($A5,"TICKER")
```
cached value/type: `WFKBALMO` (str)

### ICE_PULL!C5 — BDP NAME

```excel
=
_xll.BDP($A5,"NAME")
```
cached value/type: `Wet Frgt Plts Balm` (str)

### ICE_PULL!D5 — BDP CRNCY

```excel
=
_xll.BDP($A5,"CRNCY")
```
cached value/type: `USD` (str)

### ICE_PULL!E5 — BDP FUT_CONT_SIZE

```excel
=
_xll.BDP($A5,"FUT_CONT_SIZE")
```
cached value/type: `1000` (numeric)

### ICE_PULL!F5 — BDP FUT_TICK_SIZE

```excel
=
_xll.BDP($A5,"FUT_TICK_SIZE")
```
cached value/type: `1E-4` (numeric)

### ICE_PULL!G5 — BDP LAST_TRADE_DT

```excel
=
_xll.BDP($A5,"LAST_TRADE_DT")
```
cached value/type: `#N/A Authorization` (str)

### ICE_PULL!R4 — WFK chain

```excel
=
_xll.BDS(Tickers!$G$5&"1 Comdty","FUT_CHAIN","INCLUDE_EXPIRED_CONTRACTS=Y","CHAIN_DATE=20260401")
```
cached value/type: `WFKBALMO 20261001 Comdty` (str)

### ICE_PULL!U4 — HCE chain

```excel
=
_xll.BDS(Tickers!$G$6&"1 Comdty","FUT_CHAIN","INCLUDE_EXPIRED_CONTRACTS=Y","CHAIN_DATE=20260401")
```
cached value/type: `HCEX21 Comdty` (str)

### ICE_PULL!K12 — member-1 history (PX_SETTLE,PX_LAST)

```excel
=
IF($R$4="","",_xll.BDH($R$4,"PX_SETTLE,PX_LAST",DATE(2026,4,1),DATE(2026,10,23),"Dts=S","Days=W","Fill=N/A"))
```
cached value/type: `46113` (numeric)

### ICE_PULL!N12 — member-2 history

```excel
=
IF($R$5="","",_xll.BDH($R$5,"PX_SETTLE,PX_LAST",DATE(2026,4,1),DATE(2026,10,23),"Dts=S","Days=W","Fill=N/A"))
```
cached value/type: `46113` (numeric)

### ICE_PULL!A13 (46113)

```excel
=
DATE(2026,4,1)
```
cached value/type: `46113` (numeric)

## BALMO: parse the member date

### T_WFK!A5 — chain member ref

```excel
=
IFERROR(IF(ICE_PULL!$R$4="","REFRESH FIRST",ICE_PULL!$R$4),"BDS ERROR")
```
cached value/type: `WFKBALMO 20261001 Comdty` (str)

### T_WFK!C5 — date parse

```excel
=
IFERROR(DATE(VALUE(MID($A5,LEN($A5)-14,4)),VALUE(MID($A5,LEN($A5)-10,2)),VALUE(MID($A5,LEN($A5)-8,2))),NA())
```
cached value/type: `46296` (numeric)

### T_WFK!D5 — month end

```excel
=
IFERROR(EOMONTH($C5,0),NA())
```
cached value/type: `46326` (numeric)

### T_WFK!E5 — month start

```excel
=
IFERROR(DATE(YEAR($C5),MONTH($C5),1),NA())
```
cached value/type: `46296` (numeric)

## Window mean vs chain settle (T_WFK)

### T_WFK!I5 — WFJ in-window mean

```excel
=
IF($H5=0,NA(),SUMPRODUCT(--ISNUMBER(ICE_PULL!$B$13:$B$172),--(ICE_PULL!$A$13:$A$172>=$E5),--(ICE_PULL!$A$13:$A$172<=$F5),IFERROR(ICE_PULL!$B$13:$B$172,0))/$H5)
```
cached value/type: `59.428124999999994` (numeric)

### T_WFK!J5 — abs diff

```excel
=
IF(AND(ISNUMBER($B5),ISNUMBER($I5)),ABS($B5-$I5),"")
```
cached value/type: `2.2500249999999937` (numeric)

### T_WFK!K5 — verdict

```excel
=
IF($F5>DATE(2026,10,23),"PENDING (live window/cutoff)",IF(ISNUMBER($J5),IF($J5<=0.05,"PASS","FAIL"),"NO SETTLE/DATA"))
```
cached value/type: `PENDING (live window/cutoff)` (str)

## Monthly letter-code members (T_HCE)

### T_HCE!A5 — assembly

```excel
=
Tickers!$G$6&MID("FGHJKMNQUVXZ",MONTH($C5),1)&TEXT($C5,"yy")&" Comdty"
```
cached value/type: `HCEJ26 Comdty` (str)

### T_HCE!J5 — BDP LAST_TRADEABLE_DT

```excel
=
_xll.BDP($A5,"LAST_TRADEABLE_DT")
```
cached value/type: `30/4/2026` (str)

### T_HCE!B5 — expired final BDH

```excel
=
IFERROR(_xll.BDH($A5,"PX_SETTLE",IF(ISNUMBER($J5),$J5,DATEVALUE($J5)),IF(ISNUMBER($J5),$J5,DATEVALUE($J5)),"Dts=H","Fill=N/A"),"#N/A")
```
cached value/type: `32.704000000000001` (numeric)

### T_HCE!G5 — WFJ in-window mean

```excel
=
IF($F5=0,NA(),SUMPRODUCT(--ISNUMBER(ICE_PULL!$B$13:$B$172),--(ICE_PULL!$A$13:$A$172>=$C5),--(ICE_PULL!$A$13:$A$172<=$D5),IFERROR(ICE_PULL!$B$13:$B$172,0))/$F5)
```
cached value/type: `32.703499999999991` (numeric)

### T_HCE!H5 — abs diff

```excel
=
IF(AND(ISNUMBER($B5),ISNUMBER($G5)),ABS($B5-$G5),"")
```
cached value/type: `5.0000000000949285E-4` (numeric)

### T_HCE!I5 — verdict

```excel
=
IF($D5>DATE(2026,10,23),"PENDING (live month/cutoff)",IF(AND(ISNUMBER($B5),ISNUMBER($G5)),IF($H5<=0.05,"PASS","FAIL"),"NO SETTLE/NO DATA"))
```
cached value/type: `PASS` (str)

## Option strings that work here

```text
Dts=H     one-date scalar, hide date   |  Dts=S   history, date/value columns
Days=W    weekday axis (this workbook) |  Fill=N/A  never step-fill
invalid:  Headers=False, Dates=False (earlier draft failed with them)
```

## xbbg differs — on purpose

```text
daily:    Days='A' MANDATORY in xbbg; diagonal keeps obs only on nominal date
wrapping: xbbg returns Narwhals frames — .to_pandas() before pandas ops
monthly:  plain bdh; never pass Per='CM' to a monthly index (rc=393229)
never:    copy Days='A' into the Excel book / Days=W into the daily xbbg engine
```

## Retired statements (do not reuse)

Earlier draft's `HCEA`/`ATOA` roots, `WFJ1`/`WFK1`, `DFO1 Comdty` (resolves to Dutch
Power), hard-coded examples, `Headers=False`/`Dates=False`. The workbook + its `Handoff`
tab supersede every earlier example.
