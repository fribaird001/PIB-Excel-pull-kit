# Traps that cost real pulls

## Ticker assembly — only two shapes

- **date-stamped**: `root + " " + YYYYMMDD + " Comdty"` (WFJ/DFO daily, WFK BALMO members)
- **generic**: `root + "1 Comdty"` or the referencer active ticker `root + "A Comdty"` (e.g. `ZEA1` = `ZEAA`)
- **never stack them**: `ZEAA1 Comdty` is not a security. Specific month = `ZEAF26 Comdty`.
- **month generics** `ROOT+MMM+N` (e.g. `DORAPR1`, `COAUG1`) = Nth *unexpired* contract of that
  calendar month, so they jump to next year once this year's expires: on 2026-11-02 `DORAPR1` ->
  `DORJ27`, `COAUG1` -> `COQ7`. Not a continuous series - use explicit `DORJ26`, `DORJ27` instead.
- **Brent exception**: live Brent shows 1-digit (`COQ7`) but its DES history list uses 2-digit
  (`COQ26`, `COQ25`), and Brent expires ~2 months before delivery (`COZ26` ended 30 Oct 2026),
  so the month-end expiry rule in `bbg ticker` does not apply to it.
- **code clashes**: 77 ICE codes are another product's BBG root. `ABS` = Butane Saudi CP as ICE
  code (BBG `DJL`) but `ABS1 Comdty` = Heating Oil vs Brent (ICE HBT). Same for `FOB` (FO 1% Rdam
  `AYI` vs Ethylene `FOBX26`), `SMY` (Mogas 97 `FEO` vs Mogas 95 `SMYX26`), `DOR` (Diesel Rdam `AXD`
  vs Butane FEI `DORX26`). Check DES Exch Symbol = ICE code.
- **expiry by family (Terminal 2026-11-02, all 1,087 monthly rows)**: most expire at
  contract-month end; US gas basis/index/fixed-price (Henry, Waha, Transco, TETCO...) end of M-1;
  Baltic FFAs/indices ~24th; Brent Singapore Marker 30th; Argus WTI trade-month 25th of M-1;
  carbon/RGGI 24 Dec; RECs list only some months (e.g. July). `bbg ticker` uses the observed rule
  and rolls weekend dates back to Friday; holidays are not modelled except for `wti_style`.
- **Houston / Midland trade-month diffs (GXB, GC1, GMI, GTL, GXH, GXM, GXS, HOI, PM1, WJH, WNH)**
  follow the NYMEX WTI calendar: 3 business days before the 25th of M-1 (4 if the 25th is a
  weekend/holiday). GXB: 20 Nov 26, 21 Dec 26, 22 Mar 27, 22 Jun 27. Not "day 20".
- **TTF / NBP Last Day, NYISO capacity**: second-to-last business day of M-1 (27 Nov 26, 25 Feb 27).
- **Partial strips**: RECs, RGGI auction, CCA auction (ACA/ACP list Nov26 but not Dec26/Dec27) and
  CM1 do not list every month. `bbg ticker` marks Invalid-Security months NOT_LISTED.
- **A = 1st generic**: `ZEAA` = `ZEA1` = `ZEAZ26` (same PX_LAST; DES of ZEAA names ZEAZ26).
- **CP expiry**: Saudi/Sonatrach CP month M expires end of M-1 (`DJLZ26` -> 30 Nov 2026).
- **prefix lookalikes**: typing `DORA` also offers `DORAPR1 Comdty` (`DOR` APR monthly, **ISF**). Only the exact `DORA Comdty` (IFE active contract) is the referencer security.

BALMO members are **never** assembled by guessing — `BDS FUT_CHAIN` hands them to you formed.
Generics may answer `NAME` but hold **no price series** (`WFKBalmo1` → PX_LAST N/A).

## Month code alphabet — skips I and L

```text
FGHJKMNQUVXZ = Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec
```

`MID("FGHJKMNQUVXZ",MONTH(d),1)` — written out it is F,G,H,J,K,M,N,Q,U,V,X,Z.
Wrong alphabet = wrong ticker for 9 of 12 months (the #1 guess that breaks).

## Expired contracts

1. `LAST_TRADE_DT` can hit `#N/A Authorization` on the *generic* — that's field-level, not your root being bad.
2. Use `LAST_TRADEABLE_DT` on the **explicit member**, via `BDP`.
3. `BDP PX_SETTLE` on an expired member returns **N/A** — the correct pull is a one-date `BDH` at the
 tradeable date.
4. `LAST_TRADEABLE_DT` can arrive as **text** — pivot through
 `IF(ISNUMBER(J),J,DATEVALUE(J))` or you get #VALUE!.

## Options that are NOT here

`Headers=False` and `Dates=False` are invalid in this Terminal build — the earlier draft using them
returned errors/no data. Valid: `Dts=H | Dts=S`, `Days=W` (Excel), `Fill=N/A`.

## Excel ≠ xbbg, deliberately

| | Excel lane | xbbg lane |
|---|---|---|
| daily pull | `Days=W` | `Days='A'` **mandatory** (else empty frame) |
| calendar | weekday axis | default calendar |
| frames | n/a | Narwhals → `.to_pandas()` |
| monthly index | direct | never `Per='CM'` (BlpInternalError rc=393229) |

Never copy `Days='A'` into the Excel workbook; never copy `Days=W` into the daily xbbg engine.

## Filling

No fill anywhere. A carried-forward price manufactures a fake stable basis and passes a
match that should fail. Weekend/holiday rows stay blank.

## Roots that are traps (negative controls, on purpose)

`WFJ1` / `WFK1` fail identity. `DFO1 Comdty` resolves to Dutch Power, not TD7. `JKM` must be
`BGL`, never `XVSA`/WIM. Year width is per root: Brent `COX6` (1-digit; `COX26` is a Boston housing Index), but
IFE referencer roots use 2-digit: `ZEAF26`, `ZHAF26`, `DORF26` (`ZEAF6` does not exist).
Never guess — ladder from live `FUT_CHAIN` or check the description.

## Integrity

- ICE `Code` = Bloomberg **ID/Local Exchange Symbol**. Name-matching is excluded by design.
- `howto_ctm_*` columns are deprecated name-match output; never fetch from them.
- Sheet 143's F/D was back-filled by inference; the original build adjudicated it (`LOCKED`), so trust
 `ice_contract_type` — but do not re-open the question without new evidence.

## Sourcing tiers — Comdty before Index

1. **Dated Comdty** (`root + month code + year + " Comdty"`) — the only real curve.
2. **Generic Comdty** (`CO1`, `ZEAA`) — rolling front month; legitimate fallback, not a tense ladder.
3. **Bloomberg Fair Value curve** (`..M1 Index`) — genuine derived structure; use deliberately.
4. **Plain Index** (`NGTXAGDU GNXF INDEX`) — flat, no tenor structure. Last resort; flag
 **FLAT — NOT A CURVE** on every row.

A flat repeated PX_LAST across tenor rows is the tell for tier 4 used as if it were tier 1.

## Never trust a register over the terminal

`JKM → XVSA Comdty` in the “authoritative” ISF/CTM master turned out to be **WIM (West India
Marker)**. The correct root was `BGL`. Rule: read `BDP(ticker,"SECURITY_DES")` for the specific
contract and confirm the benchmark before building any ladder — a live-looking, curve-shaped
price is not proof it is the right instrument.

## Year digits are per root

Single-digit year is standard for most energy Comdty (`COU6`), but some roots/Index tickers use
two (`FSCOM F26 Index`). Confirm per instrument; never guess across a book.

## Three xbbg pull engines (by security shape)

| Security shape (`bbg_contract_class`) | Ticker form | Engine | Time axis & key rule |
|---|---|---|---|
| `DAILY` / `BALMO` (date-stamped) | `<FAM> <YYYYMMDD> Comdty` | `dailytickers` | `Days='A'` mandatory; keep only `obs_date == nominal YYYYMMDD` diagonal `PX_SETTLE` |
| `STANDARD_MONTHLY` (continuous root) | `<ROOT>A Comdty` / `<ROOT>1 Comdty` | `monthlytickers` | Default calendar (never `Days='A'`); never `Per='CM'` on monthly index (`rc=393229`) |
| Forward strip snapshot | `<ROOT><MONTH_CODE><YY> Comdty` | `forwardcurve` | Probe `<ROOT>1 Comdty` `SECURITY_DES`, build ladder from live `bds(..., 'FUT_CHAIN')` so year-digit width is never guessed |

## Fair-Value (CFVL) coverage boundaries

- Total fair-value tickers in the CFVL extract: **5,335** (Oil 4,888, Gas 302, Freight 145).
- ICE commodity groups outside Oil/Gas/Freight (Power/Electricity, Emissions/Carbon, Biodiesel/RED, LCFS/RECs, Agricultural) have **zero** fair-value representation in CFVL and resolve as `T4` on the fair-value leg. Never fabricate `fv_*` tickers.
