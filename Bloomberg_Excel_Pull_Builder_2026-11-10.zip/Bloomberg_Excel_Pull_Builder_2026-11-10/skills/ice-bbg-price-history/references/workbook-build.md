# Workbook build — how ICE_PULL maps together (fetcher context)

The live-verified specimen (`specimen/bdh_ice_path.xlsx`, refresh 2026-10-25, data to 2026-10-22)
ships inside this package. It has 8 tabs:
`Tickers` · `ICE_PULL` · `T1_PROXY` · `T_WFK` · `T_HCE` · `T_DIV` · `Verdict` · `Handoff`.

## Grid anatomy (`ICE_PULL`)

| Range | Shape | Formula family |
|---|---|---|
| `B13:B172` | WFJ daily diagonal | `root & " " & TEXT(date,"yyyymmdd") & " Comdty"` → `BDH PX_SETTLE, Dts=H, Days=W, Fill=N/A` |
| `C13:C172` | DFO daily diagonal | same via `Tickers!$G$7` |
| `E12:F159` | HCE1 generic history | `BDH(root&"1 Comdty",…,"Dts=S","Days=W","Fill=N/A")` |
| `H12:I159` | ATO1 generic history | same via `Tickers!$G$8` |
| `R4:R46` | WFK chain | `BDS(root&"1 Comdty","FUT_CHAIN","INCLUDE_EXPIRED_CONTRACTS=Y","CHAIN_DATE=20260401")` |
| `K12:M159` / `N12:P159` | first two chain members | `IF($R$4="","",BDH($R$4,"PX_SETTLE,PX_LAST",…,"Dts=S",…))` |
| `U4:U89` | HCE chain | same BDS pattern via `Tickers!$G$6` |
| `T_HCE!A5:…` | monthly members | `root & MID("FGHJKMNQUVXZ",MONTH(C5),1) & TEXT(C5,"yy") & " Comdty"` |
| `T_HCE!J5:B5` | expired final | `BDP LAST_TRADEABLE_DT` → one-date `BDH` |

## Verdict layer

- `T_HCE`: `|BDP member settle − WFJ populated-day mean| ≤ 0.05 → PASS`
 (mean via `SUMPRODUCT` over populated `ICE_PULL` rows inside month window; April–Sept all PASS, max diff 0.0005)
- `T_WFK`: same pattern against chain windows; live-window rows read **PENDING** — that is the cutoff
 gate, not a failure.

## Gates

Root gates live at `Tickers!J4:J8` (live `NAME` checks); daily pulls are gated at
`IF(OR($A13="",Tickers!$J$4<>"YES"),""…)`. The root-discovery block lower on `Tickers` contains
**intentional negative tests** (`WFJ1`, `WFK1`, `DFO1→Dutch power`) — do not "fix" them.

## Rules if you ever rebuild a sheet

1. `openpyxl` may create a **fresh, empty skeleton only** — a skeleton with formulas and no cached
 results. Re-saving a refreshed workbook loses Bloomberg caches and the user-authored `Handoff`.
2. Production daily formulas are gated on both non-blank date and root vote.
3. Refresh in desktop Excel with the Terminal: `Ctrl+Alt+F9`, wait for “Requesting Data”, save.
4. Respect `2006 vs 145` style history: do not enumerate beyond the window; cross-check
 `bbg manifest` call counts first.

## Historical series — one anchored BDH, auto-spill

For daily cash/history sheets (proven pattern from a production workbook):

```excel
=_xll.BDH($TickerCell,$FieldCell,$StartDateCell,$EndDateCell)
```

Set `EndDate = TODAY()` so it never goes stale. One anchored formula per series — the grid
spills downward. Do not enter a formula per cell.

## Expected cached `#N/A` warm-up cells (`T1_PROXY`)

`bdh_ice_path.xlsx` (refresh 2026-10-25, data through 2026-10-22) contains **23 cached `#N/A` cells, all on `T1_PROXY`**. They are intentional warm-up guards, not data failures — do not delete, fill, or overwrite them:

| Range | Count | Formula pattern | Why `#N/A` |
|---|---|---|---|
| `T1_PROXY!B9:B19` | 11 | `=IF(COUNT(E9:N9)<10,NA(),AVERAGE(E9:N9))` | Fewer than 10 populated WFJ observations exist before 2026-04-16 (first value `B20 = 39.517`) |
| `T1_PROXY!C9:C20` | 12 | `=IF(COUNT(O9:X9)<10,NA(),AVERAGE(O9:X9))` | Prior-10 window requires 20 populated observations; complete from 2026-04-17 (`C21 = 39.517`) |
