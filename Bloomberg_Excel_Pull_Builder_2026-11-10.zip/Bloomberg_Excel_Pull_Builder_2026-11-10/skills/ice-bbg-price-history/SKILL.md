---
name: ice-bbg-price-history
description: Resolve ICE contract codes to Bloomberg tickers, assess contract expiry and listing status, and generate conservative Excel BDH/BDP/BDS formulas or staged xbbg pull plans. Use whenever asked to map ICE codes to Bloomberg tickers, build monthly/daily/BALMO Bloomberg contract tickers, generate Excel BDH/BDP/BDS formulas or xbbg pull manifests, check ICE-to-Bloomberg identifier clashes, or audit ICE commodity price history pulls.
version: 8.4.2
runtime: Installed `bbg` CLI; Python >=3.10, standard-library runtime
---

# ICE to Bloomberg price history (full v8.4.2)

For an actual Excel pull workbook or saved-result CSV export, also use [bloomberg-excel-pull-builder](../bloomberg-excel-pull-builder/SKILL.md). This skill owns mapping, classes, listing/expiry rules and manifests; the shared builder owns workbook construction and freezing. Use fixed editable dates by default for quota-conscious archives; the older specimen's TODAY() recommendation is not the builder default.

Use this skill to resolve ICE codes and generate conservative Bloomberg Excel or `xbbg` request plans. The `icebbg` 0.2.6 wheel installs the `bbg` CLI, reference data, evidence register, documentation, and this skill. Runtime planning uses the Python standard library and requires no network access.

## Hard stops & mandatory safeguards

**Audit override:** Do not re-audit the identifier join by default. Explicit audit requests or contradictory evidence override this default. Investigate a mapping when the user asks or when live evidence conflicts, and report the conflict rather than silently editing the referencer.

1. **Never invent or manually transform an identifier.** Run the smallest applicable command through `bbg ...` and treat CLI/JSON output as authoritative.
2. **Do not re-audit the identifier join by default.** It is adjudicated (ICE code = Bloomberg `ID_EXCH_SYMBOL`; 156/156 clash sides confirmed on the Terminal 2026-11-02). Investigate a specific mapping only when explicitly asked or when live Terminal evidence contradicts it — report conflicts rather than silently editing mappings.
3. **`doctor` must be healthy** before relying on bundled data (`1,670` rows, `1,087` monthly expiry observations recomputed from rules).
4. **Preserve uncertainty status verbatim.** Never turn `LISTING_UNKNOWN`, `EXPIRY_UNKNOWN`, `NOT_LISTED`, `T4`, or `DISCOVERY_REQUIRED` into a confirmed pullable ticker. `T4` rows (57 codes) are unresolved and never pullable.
5. **Strict contract & year/month selector rules:**
   - One-digit years are invalid; use `27` or `2027`.
   - Year ranges must ascend (`27-23` is rejected with exit code `2`).
   - Do not combine a specific contract (such as `DORF26`) with `--months` or `--years` (rejected with exit code `2`).
6. **Partial-strip hold:** Products marked `partial_strip` in `expiry_register.csv` (24 codes, e.g., `ACA`, `ACP`, `CM1`, RECs, RGGI) return `LISTING_UNKNOWN` and emit **no executable history formula** unless the specific contract month is in recorded Terminal observations (`OBSERVED_LISTED`).
7. **Discovery-first BALMO:** Without validated operator-supplied member evidence (`--balmo-members`), `manifest` on a BALMO code returns `DISCOVERY_REQUIRED` (exit code `7`) and emits only `BDS(..., "FUT_CHAIN")` discovery on `<ROOT>1 Comdty`. Never fabricate dated `<ROOT> <YYYYMMDD> Comdty` BALMO tickers from calendar dates.
8. **Programmatic (`python` lane) approval & stage disclosure:** Requires `--approve` and stages `probe5` → `probe30` → `full` (capped by `--allow`). Stages are operator-controlled planning limits; this planner does not execute Bloomberg requests or verify prior probe success. Between stages, the operator must verify `SECURITY_DES` and non-empty/non-flat values before escalating.

## Commands

```bash
# 1. Health & integrity check (recomputes all 1,087 monthly expiry observations)
bbg doctor

# 2. Identifier lookup (ICE code, BBG generic, root, contract, or month generic)
bbg lookup WAH ZHAA DORF26 DORAPR1 WFJ ABG

# 3. Specific contract tickers + expiry & listing assessment + Excel recipes
bbg ticker DORA --months F,Z --years 27 --asof 2026-11-03 --formulas

# 4. Pull manifest — default Excel lane (no approval needed)
bbg manifest DFO --start 2026-11-02 --end 2026-11-03 --json

# 5. Pull manifest — programmatic Python/xbbg lane (requires explicit approval + stage)
bbg manifest DFO --start 2026-11-02 --end 2026-11-03 \
  --lane python --stage probe5 --approve --json

# 6. Canonical formula patterns & embedded docs
bbg formula daily,monthly_generic,chain,chain_member_history,member_date_parse,monthly_member,expired_final
bbg docs
```

## BALMO evidence handoff (`--balmo-members`)

After the operator runs `FUT_CHAIN` in a Bloomberg-capable environment, pass a JSON file with `schema_version: "1"`:

```json
{
  "schema_version": "1",
  "products": [{
    "ice_code": "ABG",
    "discovery_security": "ABGBALMO1 Comdty",
    "discovery_date": "2026-11-02",
    "source_description": "operator Terminal export",
    "members": ["ABGBALMO 20261102 Comdty"]
  }]
}
```

Then run:

```bash
bbg manifest ABG --start 2026-11-02 --end 2026-11-03 \
  --balmo-members members.json --json
```

The file is operator-supplied evidence, not independent live verification. Product code, discovery security (`<ROOT>1 Comdty`), ISO dates, and `<ROOT> <YYYYMMDD> Comdty` member formats are strictly validated before history operations are emitted.

## References

Load these on demand when deeper formula syntax, sourcing traps, or workbook layout rules are needed:

- `references/formulas.md` — BDP/BDH/BDS syntax, `Days`/`Fill` options, expired-contract two-step recipe, and date-parsing formulas.
- `references/traps.md` — 78 identifier clashes (`WAH`, `JKM`/`XVSA`, etc.), daily/BALMO diagonal rule, partial-strip hold list, and CFVL fair-value coverage boundaries.
- `references/workbook-build.md` — 7-sheet `bdh_ice_path.xlsx` layout, cell-budget sizing, and expected `T1_PROXY` warm-up `#N/A` guards.
