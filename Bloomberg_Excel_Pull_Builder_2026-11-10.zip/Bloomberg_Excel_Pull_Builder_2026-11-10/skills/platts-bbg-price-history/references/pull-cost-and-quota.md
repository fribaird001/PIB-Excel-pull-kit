# Efficient Platts history pulls through Bloomberg

Verified research: 6 November 2026. These rules concern Platts assessments retrieved through Bloomberg BDH/Desktop API. They do not establish the charging rules of the direct S&P Global/Platts API or a contractual per-download price. Here, cost primarily means download-quota usage and unnecessary requests.

## Plan requests by security, field and execution

Use one raw BDH range formula per exact security and field. A request such as BDH("PCRUBCD1 Index","PX_LAST","2000-01-01","2026-11-05") asks for one security/field pair over a period. Returned historical dates and the returned date column are not additional requested fields. Avoid one BDH per date: 16 securities over 1,000 dates then require 16,000 formula executions instead of 16 range executions.

The reproduced Bloomberg ManApiLimits guidance counts daily security/field pairs per request, including repeats. Under this documented model, 16 one-field ranges executed once are 16 hits, 51 are 51, and both once are 67. A whole network request containing several securities or fields is not necessarily one hit. Count each security/field pairing. Formula count is a planning estimate: actual refreshes, retries and other account work are not observable from a saved workbook alone.

Monthly usage is a separate measure: unique securities per data/request category within a calendar month. In the reproduced Bloomberg guidance, reuse of a security within the historical category counts once, regardless of historical-period length or field count. The same security used in another category can add monthly usage. A long historical window is therefore not inherently more monthly securities; splitting it into many windows creates more daily request executions without reducing that category's unique-security breadth.

The 3,500 concurrent real-time restriction is separate; it is not a historical batch-size allowance. Published 500,000 daily and 4,000–7,000 monthly figures are public guidance, not a verified ceiling or remaining allowance for this corporate account. The actual monthly threshold and category weights are not transparent.

## Practical workflow

1. Reconcile exact Platts IDs against the eligible map, prior saved raw prices and the direct reference inventory. A missing reference row is not proof of missing direct value access: ATFNA00 had saved direct prices despite its reference omission. Preserve raw/count-only/historical evidence labels.
2. Reuse the local archive. Inspect cached workbook values or frozen CSVs before any new vendor query. For incremental updates, request the missing end dates; inspect interior gaps locally before deciding which need repair. First/last dates alone do not certify complete coverage.
3. Select only needed securities and fields. Use PX_LAST for these plans unless another field is explicitly required. Dedupe exact identities and ranges; preserve intentional different aliases/fields as separate operations. Exclude already-tested empty leads from routine archives unless new evidence or the user justifies a retry. Add zero controls, identity probes, screens or companion requests by default.
4. Choose the history window for the analytical need and known lifecycle. Do not split a long range across days merely to save hits. Batching may still help inspect results, preserve partial progress or manage workbook size; describe that purpose accurately. For Day-N grade curves, the documented symbol programme begins 2024-12-02. Sparse late-window positions, monthly averages and discontinued series keep their native dates.
5. When asked for a refresh sheet, deliver an actual XLSX, not only a ticker CSV. Generate and save the kit manifest, then author one native raw BDH range formula per selected security in separate empty two-column spill areas. Use fixed editable start/end dates and manual calculation. Avoid volatile TODAY/NOW date drivers and per-date formulas. Preserve vendor errors; COUNT(BDH) and IFERROR are not substitutes for an archive of prices.
6. Check IDs, date routing, unique operations and empty spill areas offline. Report the request count and any rejected identifiers. Opening Excel or refreshing Bloomberg is a separate action; preparing a file does not execute it. Refresh only the intended workbook/portion once, wait and save; repeated reopening/recalculation may add executions.
7. After the user saves, extract cached results without Excel recalculation or vendor calls. Freeze to literal CSVs with exact IDs, ISO dates, numeric values and provenance. Preserve nonnumeric/error rows separately, never convert missing prices to zero or fill them forward. Excel dates may be serial numbers even with General formatting; normalise known date columns within the request bounds, retaining raw representations. Preserve numeric cache strings where possible.
8. Verify formula-free CSVs, ID/date uniqueness, overlap conflicts, coverage and source hashes. Keep originals unchanged and direct users to the frozen files for ordinary analysis. Record planned formula operations, actual refresh count if known, unique securities/category, returned price observations and provider charge as different ledger quantities.

## What not to infer

- Returned prices/cells are archive volume, not measured hit debits. The 421,004 saved prices in the current archive do not mean 421,004 daily hits.
- A saved successful pull does not reveal the remaining quota, remove a possible usage review, guarantee future access or certify permission after an entitlement realignment.
- The earlier 300,000 planning baseline and 44,109 arithmetic remainder are not provider capacity. Two cap events and a provisional enablement do not establish a new allowance.
- A 100,000-plus identifier discovery sweep has very different monthly breadth from a small long-history archive. It is a plausible explanation for an earlier anomaly, not a verified diagnosis of the cap events.
- Do not infer direct Platts API metering from Bloomberg's rules. Direct-feed cost rules need separate provider/account evidence.

## Sources and evidence strength

The companion BLOOMBERG_LIMIT_VERIFICATION_2026-11-06.md retains the fuller research and source assessment.

- Strongest: Bloomberg's own ExtRules and ManApiLimits help text reproduced on PDF pages 3–4 of the University of Zurich guide, filename dated 20180309: https://www.df.uzh.ch/dam/jcr%3Af081029c-6875-44a2-93a2-2d9394efe4cb/How_to_use_the_Bloomberg_terminals_20180309.pdf . Page 4 item 2 explicitly excludes historical-period length from the monthly unique-security calculation; item 3 defines daily security/field hit totals; item 8 warns about volatile-date BDH recalculation. This is an older reproduced help page, not a current account-specific policy response.
- St. Gallen guide, dated 20 March 2026: https://www.unisg.ch/fileadmin/user_upload/HSG_ROOT/_Kernauftritt_HSG/Universitaet/Bibliothek/Suchen_und_Nutzen/Datenbanken/Datenbankseiten/A-Z/Bloomberg/Bloomberg_Download_Limitations.pdf . Confirms the public daily-pair/monthly-unique-security model.
- HKUST Library, updated January 2025: https://libguides.hkust.edu.hk/c.php?g=208028&p=6948363 . Confirms the ten-securities/five-fields = 50-hit example and distinguishes the three limits; does not explicitly address historical-period length.
- UBC Library, updated October 2026: https://guides.library.ubc.ca/finance/bloomberg . Corroborates monthly unique securities/data types and reuse. University pages may share underlying Bloomberg guidance and are not independent account measurements.
- Bloomberg API documentation: https://github.com/bloomberg/blpapi-http/blob/develop/doc/http-api-guide.md . Confirms historical request mechanics; it does not itself establish quota charging.

No current corporate-account ceiling or remaining balance was verified. Reddit, third-party code counters and user-posted support quotations were not treated as authoritative charging specifications. Ask the existing Bloomberg support ticket for current account-specific confirmation if needed; this document authorises no support message or live limit test.
