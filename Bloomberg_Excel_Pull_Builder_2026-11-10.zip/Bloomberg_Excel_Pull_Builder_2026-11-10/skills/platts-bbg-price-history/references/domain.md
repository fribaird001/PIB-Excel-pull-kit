# Domain interpretation

Lookup policy includes every observed extra: 17 October raw-supported, 32 October count-positive and 19 historical-only. Retain evidence labels when proposing a date range. The user explicitly merged these into the same eligible map. Current access and real-time freshness are separate from lookup eligibility.

Platts daily, weekly and monthly-average symbols are separate IDs. A Mo01 rolling assessment is not a fixed futures contract; never append ICE month letters or infer an expiry from its name. Dates/bates belong to direct values but Bloomberg PX_LAST is a separate field. Direct metadata frequency, currency and units apply to the source reference record; check Bloomberg output identity/units when actual values are retrieved.

The saved probe recipe used Index; both aliases resolving in an earlier probe does not certify the yellow key. Preserve an explicit user suffix. Missing mappings remain DIRECT_ONLY or UNKNOWN; return those dispositions instead of inventing identities.

Default history output is raw BDH. Separate empty spill areas prevent overlapping series. `--screen-count` can hide text errors as zero and counts dates alongside prices. Historical values can survive publication discontinuation, and an average can legitimately have a single monthly observation.

Local formula counts are not verified provider charging. A historical request covers a range; N=44 is not44 separate calls. Refreshes incur additional unobserved usage. The earlier provisional enablement has unknown capacity. Avoid generating the entire eligible universe as a casual status check.

The AASFE*/AASFG* blend-value hits are documented RBOB-relative calculations; the newer outright ALK* family is distinct. CEC euro values are carbon representations, not FX instruments. The MEM differential LMEMG00 is scheduled to discontinue4January2027; historical requests may still be meaningful.
