# Bloomberg historical-range quota verification — 6 November 2026

## Conclusion

Public evidence strongly supports counting a single-security, single-field BDH range request as one daily security/field hit per execution, rather than one hit per returned historical date. The monthly measure is distinct: unique securities per request/data category within a calendar month. Historical request length is explicitly excluded from the monthly unique-security count in the reproduced Bloomberg help text.

This establishes the documented counting model, not the current licence-specific ceiling, remaining allowance, actual Excel refresh attempts or any separate usage review. No live requests were made to test limits.

## Strongest source: reproduced Bloomberg help pages

[University of Zurich, How to use the Bloomberg terminals](https://www.df.uzh.ch/dam/jcr%3Af081029c-6875-44a2-93a2-2d9394efe4cb/How_to_use_the_Bloomberg_terminals_20180309.pdf), filename dated 20180309. This is an older public copy, not a newly obtained corporate-account policy.

- PDF page 3 reproduces Bloomberg's Extended Rules and Usage Limits, reference ExtRules. It defines daily hits by security/field pairs and monthly usage by unique securities per data category.
- PDF page 4 reproduces Bloomberg's Managing Your API Data Limits, reference ManApiLimits. Item 2 states that the same security in the same request category counts once per calendar month regardless of field count or historical-period length. Switching categories can add monthly usage for the same security.
- Page 4 item 3 sums security/field pairs for daily hits and explicitly includes repeat requests.
- Page 4 item 8 specifically warns that repeatedly recalculating BDH with TODAY/NOW increases daily security/field hits.
- The university's own advice on page 2 also explains that BDH retrieves a whole historical vector in one server access. The reproduced Bloomberg text is the stronger evidence for quota semantics.

## Corroboration and limits of independence

1. [University of St. Gallen, Bloomberg Download Limitations](https://www.unisg.ch/fileadmin/user_upload/HSG_ROOT/_Kernauftritt_HSG/Universitaet/Bibliothek/Suchen_und_Nutzen/Datenbanken/Datenbankseiten/A-Z/Bloomberg/Bloomberg_Download_Limitations.pdf), dated 20 March 2026: daily security/field-pair definition; 500,000 daily guideline; monthly unique-security/data-type model, reuse within month, undisclosed capacity. This is the user's supplied guide, independently retrieved and checked.
2. [HKUST Library, API Download Limit](https://libguides.hkust.edu.hk/c.php?g=208028&p=6948363), page updated 2 January 2025: 10 securities times five fields equals 50 daily hits; separately describes monthly and real-time limits. It does not expressly address date-range length.
3. [UBC Library, Bloomberg data limits](https://guides.library.ubc.ca/finance/bloomberg), page updated 8 October 2026: monthly unique securities and data type, reuse within a month, licence-specific allocation. It supplies no explicit BDH daily date-range rule.
4. [Bloomberg's own API documentation](https://github.com/bloomberg/blpapi-http/blob/develop/doc/http-api-guide.md), archived repository: historical requests specify securities, fields and start/end dates and return dated rows. This confirms request mechanics, not quota pricing on its own.

The university descriptions may share underlying Bloomberg guidance. Multiple websites are corroboration of the published rule, not independent measurements of the user's account. The user-posted Help Desk quotation on Stack Overflow was inspected but was not needed as authoritative evidence; neither Reddit anecdotes nor third-party skill repositories determine the conclusion.

## Application to the archive

- 16 securities x PX_LAST x one execution: 16 documented security/field hits.
- 51 securities x PX_LAST x one execution: 51 documented security/field hits.
- Both once: 67 hits under this model. Actual consumption can be higher if Excel refreshes or retries the formulas more than once.
- Monthly footprint: 67 unique securities in the historical category across these workbooks, not necessarily 67 NEW securities that month. Earlier historical requests may already have counted them. Other work and other categories remain outside this number.
- The 205,651 saved price observations are output volume, not a demonstrated daily hit debit or remaining quota calculation.
- Splitting one security/field's long period into ten BDH requests generates ten executions under the daily model. It does not create ten different monthly securities in the same category. Date splitting is therefore not inherently quota-saving.
- One formula per ticker per date is much more request-intensive than one range formula per ticker. Returned Excel cells and requested provider fields are different quantities; the returned date column is not another separately requested field.
- The 3,500 real-time restriction is separate and does not provide a historical batch-size allowance.

## Correction and remaining uncertainty

Earlier treating returned price counts as a direct quota-risk proxy was unsupported. The initial interpretation of the user's university guide was conditional; the reproduced Bloomberg ManApiLimits text now provides substantially stronger evidence for security/field request counting and historical-period independence in monthly usage.

The historical 100,000-plus identifier discovery sweep was a much broader unique-security workload than these 67-security archives. That is a plausible explanation for the earlier monthly/anomaly problem, not a verified diagnosis of the user's two cap events. Their exact cap/error type and provisional grant are not established here.

Current account-specific confirmation would come from Bloomberg's current API Data Limits help or existing support ticket, asking whether a single-security PX_LAST HistoricalDataRequest counts once regardless of daily observations and whether the historical category is counted once per unique security per calendar month. No support message was sent and no further pull was prepared by this verification.
