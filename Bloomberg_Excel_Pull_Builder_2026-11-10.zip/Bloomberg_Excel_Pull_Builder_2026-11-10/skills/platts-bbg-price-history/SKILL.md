---
name: platts-bbg-price-history
description: Resolve Platts assessment IDs or Bloomberg tickers against the bundled eligible map and prepare counted Excel history plans with access-evidence provenance. Use for Platts assessment lookup and history recipes; ICE contract expansion uses the separate ICE kit.
---

# Platts assessment lookup and history plans

For an actual Excel refresh workbook or saved-result CSV export, also use [bloomberg-excel-pull-builder](../bloomberg-excel-pull-builder/SKILL.md). This skill owns Platts identity/evidence and manifests; the shared builder owns workbook construction, verification and freezing.

Use the `platts-bbg` CLI from `platts-bbg-kit`. It is an offline referencer/planner; a generated plan is not a live pull.

1. Resolve the exact supplied identifier with `platts-bbg lookup <IDs> --json`. Use `platts:<ID>` or `bbg:<ticker>` to settle namespace collisions. Description search returns candidates to choose from; unknowns retain their original requested identity.
2. Preserve evidence types. The default eligible set includes all user-approved historical/count-only extras as well as raw-supported observations. They remain valid lookup references; their saved dates do not establish current prices. DIRECT_ONLY supports a direct reference lookup but has no Bloomberg mapping.
3. For history, generate `platts-bbg manifest <IDs> --start YYYY-MM-DD --end YYYY-MM-DD --out plan.json`. The default is raw PX_LAST BDH, zero controls, no execution. Read outcome/dispositions and formula count before handing the plan to the user. PARTIAL/ALL_REJECTED/OVER_CEILING must be visible.
4. Save the complete manifest next to its task. An optional recipes CSV contains inert formula text; raw BDH responses need separate empty spill areas. A returned text error must remain visible. COUNT screening is an explicit alternative with weaker interpretation.

Use `platts-bbg doctor` for local resource integrity, not evidence of live access. Use `platts-bbg docs history` when preparing a nontrivial history plan, or read [references/domain.md](references/domain.md) when interpreting tenors, fields or evidence.

Specific invariants: exact Platts ID is the join; roots/names are not identities. Assessment Mo01/Wk01 is not an ICE delivery-contract synthesis rule. The Index suffix is an empirical recipe default, not canonical identity certification. Extra identity/control requests are not silently added. Preserve raw errors; empty/missing data is not a zero price. Explicit audit requests or contradictory source metadata warrant a targeted investigation rather than silent remapping.

The kit contains no live Bloomberg executor or direct Platts value adapter. This skill supplies lookup/plans within the user's task; it does not authorize external messages, account setup, installation or automatic refreshes.

## Efficient pulls and frozen archives

For history plans, refresh workbooks, quota estimates or saved-result reviews, read [pull-cost-and-quota.md](references/pull-cost-and-quota.md). Use one raw BDH range per exact security/field, reuse saved data and request uncovered dates, with zero controls by default. Daily security/field executions, monthly unique securities per category and returned price rows are different quantities; historical date count is not a daily-hit multiplier under the documented model. Splitting dates is not inherently quota-saving, and 3,500 real-time subscriptions is not a historical batch allowance. Account-specific capacity remains unverified.

When the user asks for a refresh sheet, deliver a real Excel workbook with editable fixed dates, separate raw spill areas and manual calculation, using the available spreadsheet-authoring workflow after saving the kit manifest. The CLI alone does not build XLSX files. After the user saves, freeze cached results to literal CSV without Excel recalculation or vendor requests; preserve errors, sparse dates and provenance. Use the frozen archive for subsequent offline work.
