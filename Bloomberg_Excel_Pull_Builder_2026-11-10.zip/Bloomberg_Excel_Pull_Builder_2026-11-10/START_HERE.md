# Bloomberg Excel Pull Builder kit

Version: 2026-11-10. Offline authoring kit; no Bloomberg executor. Includes source helper scripts, installed builder skill/references, companion ICE and Platts skill instructions, and a user-refreshed full-history example with saved evidence.

## Decode and extract

The companion .zip.base64.txt is plain ASCII base64 of the ZIP, not an executable. Decode with Python:

    python -c "import base64,pathlib; p=pathlib.Path('Bloomberg_Excel_Pull_Builder_2026-11-10.zip.base64.txt'); p.with_suffix('').write_bytes(base64.b64decode(p.read_bytes(),validate=False))"

The result ends in .zip.base64; rename to .zip or open it as a ZIP. Alternatively certutil -decode INPUT.base64.txt OUTPUT.zip on Windows. Check the supplied SHA256 before extraction.

## What is included and what is required

skills/bloomberg-excel-pull-builder is the complete builder instruction/source folder. scripts/build_pull.mjs authors workbooks through @oai/artifact-tool; scripts/verify_pull.py finalises/checks new offline files; scripts/test_verifier.py contains negative tests for the ICE trial. CSV freezing is a documented workflow, not an implemented exporter in this package.

skills/ice-bbg-price-history and skills/platts-bbg-price-history contain the companion instructions/references so their sibling links work. This archive DOES NOT contain their full mapping databases, wheels, CLI installations, Terminal add-in, Node/Python runtimes, or @oai/artifact-tool. Obtain the existing ICE and Platts kits separately and run their integrity checks. Do not treat copied instructions as a replacement for their data-backed resolvers. No new dependency installation is performed by this archive.

## How ticker identification links to construction

ICE request -> ice-bbg-price-history -> installed bbg CLI/referencer -> accepted manifest -> builder -> Excel -> user refresh/save -> cache-only export/review.

    bbg doctor
    bbg lookup WFJ WFK JFG
    bbg manifest WFJ JFG --start 2026-10-01 --end 2026-10-02 --json --out ice_plan.json

ICE codes are not necessarily Bloomberg roots: JFG resolves to HCEA Comdty. Use exact CLI output, listing/expiry status and class. BALMO member discovery/evidence must precede member pricing. See companion skill for --balmo-members schema. The CLI's daily/BALMO histories may be nominal-date diagonals: explicitly adapt the manifest to full observation-date ranges when that is the user's intent. Preserve original manifest and record adaptation; do not silently change identifiers.

Platts request -> platts-bbg-price-history -> platts-bbg eligible map -> exact assessment ID/Bloomberg mapping -> manifest -> same builder.

    platts-bbg lookup PCAAS00 --json
    platts-bbg manifest PCAAS00 --start 2026-11-06 --end 2026-11-09 --out platts_plan.json

If using the source kit without an installed CLI, use its documented run.py entrypoint. Eligible/count-only/historical evidence does not guarantee current access. Platts Day-N/Mo01/Wk01 labels are assessment tenors, not ICE dated-contract templates.

## Install and run the builder

Copy skills/bloomberg-excel-pull-builder into the target Codex skills root. Keep existing companion skills if they are newer; review differences before replacing. Relative sibling links expect the three skill folders under the same root. Invoke $bloomberg-excel-pull-builder together with the appropriate domain skill.

Read the spreadsheets skill, locate bundled runtime and node_modules through load_workspace_dependencies, and run its creation marker once before authoring. Then, using actual runtime paths:

    node skills/bloomberg-excel-pull-builder/scripts/build_pull.mjs plan.json NEW_OUTPUT_DIR RUNTIME_NODE_MODULES [identity-evidence.json]
    python skills/bloomberg-excel-pull-builder/scripts/verify_pull.py NEW_OUTPUT_DIR --finalize
    python skills/bloomberg-excel-pull-builder/scripts/verify_pull.py NEW_OUTPUT_DIR

The builder accepts small ICE/Platts one-security/one-field history manifests, maximum 40 operations; refuses existing output folders; emits no BDP/BDS controls. Omitted ICE identity operations require saved evidence. Discovery-only, multi-field and large consolidated layouts use the general skill workflow. Helpers are not a general live retrieval engine.

## Essential rules and saved example

Full member history and a realised diagonal are separate products. Embedded YYYYMMDD identifies a member, not its only price date. Obtain exact BALMO members from accepted chain evidence; no calendar guesses. One range BDH per exact member/field retrieves its requested observation history; derive diagonals offline afterwards. DAILY is a contract class, not merely daily history frequency.

Read references/wfj-wfk-lifecycle.md: WFK's two-month listing horizon differs from WFJ's 130-business-day listing horizon. They do not certify exact first/last Bloomberg prices. Historical/current expiry sources conflict; preserve effective-date uncertainty. Weekday Excel Days=W behaviour is not a verified weekend rule and is not interchangeable with xbbg Days='A'. Never fill missing prices.

examples/corrected_member_windows_2026-11-10/sheet/Bloomberg_Trial.xlsx is USER-REFRESHED EVIDENCE, not a fresh template. DO NOT run --finalize or re-save it through a workbook writer: retain its real caches. It has 44 BALMO prices (Sep 1–Oct 30) and 134 DAILY prices (Mar 31–Oct 5). BALMO touches both request boundaries, so full lifecycle coverage is unproven. Build a NEW workbook from the example manifest if needed rather than automatically refreshing this evidence. Stored absolute source paths are provenance from the original machine; resolve local resources explicitly after transfer.

No provider quota balance or entitlement is certified. Count formulas, security/field executions, monthly unique securities and returned prices separately. Manual calc mitigates accidental refresh but does not control all add-in behaviour. Preparing files performs no Bloomberg queries.
